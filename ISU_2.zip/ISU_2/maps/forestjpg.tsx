<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.4" name="forestjpg" tilewidth="32" tileheight="32" tilecount="1920" columns="60">
 <image source="../images/SpriteSheet/forestjpg.jpg" width="1920" height="1054"/>
</tileset>
