<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.4" name="sprite7" tilewidth="32" tileheight="32" tilecount="6" columns="6">
 <image source="../images/Text/sprite7.png" width="193" height="47"/>
</tileset>
