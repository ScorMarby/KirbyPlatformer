<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.4" name="background" tilewidth="16" tileheight="16" tilecount="144" columns="16">
 <image source="../images/SpriteSheet/2015-02-26 [DB32](Generic Platformer)(Mountains).png" width="256" height="144"/>
</tileset>
