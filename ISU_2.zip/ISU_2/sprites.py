import pygame as pg
from settings import *
vec = pg.math.Vector2
from itertools import chain




# player and mobs
class Player(pg.sprite.Sprite):
    def __init__(self, game, x, y):
        self.groups = game.all_sprites
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.image = pg.Surface((TILESIZE *3, TILESIZE*3))
        self.rect = self.image.get_rect()
        self.pos = vec(x, y)
        self.rect.center = self.pos
        # animation stuff
        self.animationsFrames = {}
        self.animationDataBase = {}
        self.animationDataBase["Idle"] = self.load_animations("images/Kirby Sprites/Idle", [18, 14, 18])
        self.animationDataBase["Run"] = self.load_animations("images/Kirby Sprites/Run", [7, 7, 7, 7, 7, 7, 7, 7])
        self.animationDataBase["Jump"] = self.load_animations("images/Kirby Sprites/Jump", [7,7,7,7,7,7,7,7,7,7])
        self.animationDataBase["Attack"] = self.load_animations("images/Kirby Sprites/Attack", [8,6,8])
        self.currentFrame = 0
        self.animationState = "Idle"
        self.attacking = False
        self.player_flip = False
        #attack
        self.last_attack = 0
        # velocity and acceleration
        self.vel = vec(0, 0)
        self.acc = vec(0, 0)
        self.rot = 0
        self.last_shot = 0
        #health
        self.health = player_HEALTH
        self.score = score
        self.damage = False

    def jump(self):
        # jump only if standing on a platform
        self.rect.y += 1
        hits = pg.sprite.spritecollide(self, self.game.walls, False)
        self.rect.y -= 1
        if hits:
            self.game.effects_sounds["jump"].set_volume(1)
            self.game.effects_sounds["jump"].play()
            self.vel.y = -player_JUMP



    def attack(self):
        now = pg.time.get_ticks()
        if self.vel.x == 0:
            self.attacking = True
            self.animationState, self.currentFrame = self.changeState(self.animationState, self.currentFrame, "Attack")
            self.game.effects_sounds["attack"].set_volume(0.2)
            self.game.effects_sounds["attack"].play()
            for enemy in self.game.WaddleDoo:
                if self.attackBox.colliderect(enemy.rect):
                    enemy.health -= player_Damage
                    self.game.effects_sounds["damage"].set_volume(0.05)
                    self.game.effects_sounds["damage"].play()
                    self.score += 10
            for enemy in self.game.WaddleDee:
                if self.attackBox.colliderect(enemy.rect):
                    enemy.health -= player_Damage
                    self.game.effects_sounds["damage"].set_volume(0.05)
                    self.game.effects_sounds["damage"].play()
                    self.score += 10
            for enemy in self.game.Scarfy:
                if self.attackBox.colliderect(enemy.rect):
                    enemy.health -= player_Damage
                    self.game.effects_sounds["damage"].set_volume(0.05)
                    self.game.effects_sounds["damage"].play()
                    self.score += 30
            for enemy in self.game.Burnin:
                if self.attackBox.colliderect(enemy.rect):
                    enemy.health -= player_Damage
                    self.game.effects_sounds["damage"].set_volume(0.05)
                    self.game.effects_sounds["damage"].play()
                    self.score += 50
            for enemy in self.game.Chilly:
                if self.attackBox.colliderect(enemy.rect):
                    enemy.health -= player_Damage
                    self.game.effects_sounds["damage"].set_volume(0.05)
                    self.game.effects_sounds["damage"].play()
                    self.score += 20
            for wall in self.game.DestroyWall:
                if self.attackBox.colliderect(wall.rect):
                    self.score += 1
                    wall.kill()

    # more animation stuff
    def load_animations(self, path, frame_dur):
        animationName = path.split("/")[-1]
        animationFrameData = []
        n = 0
        for frames in frame_dur:
            animationID = animationName + str(n)
            imgLocation = path + "/" + animationID + ".png"
            animationImage = pg.image.load(imgLocation).convert_alpha()
            #resize images
            if animationName == "Attack":
                animationImage = pg.transform.scale(animationImage, (80, 60))
            elif animationName == "Run":
                animationImage = pg.transform.scale(animationImage, (56, 60))
            elif animationName == "Idle":
                animationImage = pg.transform.scale(animationImage, (56, 67))
            elif animationName == "Jump":
                animationImage = pg.transform.scale(animationImage, (56, 60))

            self.animationsFrames[animationID] = animationImage.copy()
            for i in range(frames):
                animationFrameData.append(animationID)
            n += 1
        return animationFrameData

    def changeState(self, currentState, Frame, newState):
        if currentState != newState:
            currentState = newState
            Frame = 0
        return newState, Frame

    #when hit play sound and change colour
    def hit(self):
        self.damage = True
        self.damage_alpha = chain(damage_alpha)
        self.game.effects_sounds["damage"].set_volume(0.05)
        self.game.effects_sounds["damage"].play()

    def update(self):
        #makes the attack box
        self.attackBox = pg.Rect(self.rect.x - 15, self.rect.y, 85, 30)
        self.attacking = False
        #left and right movement
        self.acc = vec(0, player_GRAV)
        keys = pg.key.get_pressed()
        if keys[pg.K_a]:
            self.acc.x = -player_ACC
        if keys[pg.K_d]:
            self.acc.x = player_ACC
        if keys[pg.K_e]:
            # attack stuff
            self.attack()


        # apply friction
        self.acc.x += self.vel.x * player_FRICTION
        # equations of motion
        self.vel += self.acc

        self.rect.x += self.vel.x + 0.5 * self.acc.x

        # collision
        collision_list = pg.sprite.spritecollide(self, self.game.walls, False)

        for collision in collision_list:
            if self.vel.x > 0:
                self.vel.x = 0
                self.rect.right = collision.rect.left

            elif self.vel.x < 0:
                self.vel.x = 0
                self.rect.left = collision.rect.right

        self.rect.y += self.vel.y + 0.5 * self.acc.y

        collision_list = pg.sprite.spritecollide(self, self.game.walls, False)

        for collision in collision_list:
            if self.vel.y > 0:
                self.vel.y = 0
                self.rect.bottom = collision.rect.top

            elif self.vel.y < 0:
                self.vel.y = 0
                self.rect.top = collision.rect.bottom

        # spike damage
        collision_list = pg.sprite.spritecollide(self, self.game.spikes, False)

        for collision in collision_list:
            self.health -= collision.damage

        # flag collision
        collision_list = pg.sprite.spritecollide(self, self.game.flag, False)

        for collision in collision_list:
            self.game.playing = False

        # health
        collision_list = pg.sprite.spritecollide(self, self.game.HP, False)

        for collision in collision_list:
            self.health += collision.health
            collision.kill()

        # coin
        collision_list = pg.sprite.spritecollide(self, self.game.coin, False)

        for collision in collision_list:
            self.score += collision.score
            self.game.effects_sounds["coin"].set_volume(0.1)
            self.game.effects_sounds["coin"].play()
            collision.kill()

        if self.health > player_HEALTH:
            self.health = player_HEALTH

        # also animation
        if self.vel.x > 0 and self.attacking == False:
            self.animationState, self.currentFrame = self.changeState(self.animationState, self.currentFrame, "Run")
            self.player_flip = False

        if self.vel.x == 0 and self.attacking == False:
            self.animationState, self.currentFrame = self.changeState(self.animationState, self.currentFrame, "Idle")

        if self.vel.x < 0 and self.attacking == False:
            self.animationState, self.currentFrame = self.changeState(self.animationState, self.currentFrame, "Run")
            self.player_flip = True

        if self.vel.y < 0:
            self.animationState, self.currentFrame = self.changeState(self.animationState, self.currentFrame, "Jump")

        #appends animation frames
        self.currentFrame += 1
        if self.currentFrame >= len(self.animationDataBase[self.animationState]):
            self.currentFrame = 0

        self.imgID = self.animationDataBase[self.animationState][self.currentFrame]
        self.image = pg.transform.flip(self.animationsFrames[self.imgID], self.player_flip, False)


        # health settings

        if self.damage:
            try:
                self.image.fill((255, 0 ,0, next(self.damage_alpha)), special_flags=pg.BLEND_RGBA_MULT)
            except:
                self.damage = False
        if self.health <= 0:
            self.kill()


class WaddleDooR(pg.sprite.Sprite):
    def __init__(self, game, x, y):
        self.groups = game.all_sprites, game.WaddleDoo
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.image = pg.Surface((TILESIZE * 3, TILESIZE * 3))
        self.rect = self.image.get_rect()
        self.pos = vec(x,y)
        self.rect.center = self.pos
        # animation stuff
        self.animationsFrames = {}
        self.animationDataBase = {}
        self.animationDataBase["Idle"] = self.load_animations("images/Waddle Doo/Idle", [18, 14, 18])
        self.animationDataBase["Run"] = self.load_animations("images/Waddle Doo/Run", [5, 5, 5, 5, 5])
        self.animationDataBase["Attack"] = self.load_animations("images/Waddle Doo/Attack", [8, 6])
        self.currentFrame = 0
        self.animationState = "Idle"
        self.player_flip = False
        self.attacking = True
        #way its facing
        self.vel = vec(0, 0)
        self.acc = vec(0, 0)
        #health
        self.health = WaddleHealth
        self.enemyHealth = player_HEALTH


    #more animation stuff
    def load_animations(self, path, frame_dur):
        animationName = path.split("/")[-1]
        animationFrameData = []
        n = 0
        for frames in frame_dur:
            animationID = animationName + str(n)
            imgLocation = path + "/" + animationID + ".png"
            animationImage = pg.image.load(imgLocation).convert_alpha()
            #resize images
            if animationName == "Attack":
                animationImage = pg.transform.scale(animationImage, (73, 55))
            elif animationName == "Run":
                animationImage = pg.transform.scale(animationImage, (56, 60))
            elif animationName == "Idle":
                animationImage = pg.transform.scale(animationImage, (TILESIZE *4, 60))

            self.animationsFrames[animationID] = animationImage.copy()
            for i in range(frames):
                animationFrameData.append(animationID)
            n += 1
        return animationFrameData

    def changeState(self, currentState, Frame, newState):
        if currentState != newState:
            currentState = newState
            Frame = 0
        return newState, Frame

    def update(self):
        # left and right movement
        self.acc = vec(0, player_GRAV)
        if self.player_flip == False:
            self.acc.x = mob_ACC
        else:
            self.acc.x = -mob_ACC

        # apply friction
        self.acc.x += self.vel.x * player_FRICTION
        # equations of motion
        self.vel += self.acc

        # attack stuff
        if self.rect.colliderect(self.game.player.rect):
            self.game.player.health -= WaddleDamage
            self.game.player.hit()

        self.rect.x += self.vel.x + 0.5 * self.acc.x

        collision_list = pg.sprite.spritecollide(self, self.game.walls, False)

        for collision in collision_list:
            if self.vel.x > 0:
                self.vel.x = 0
                self.rect.right = collision.rect.left
                self.player_flip = True

            elif self.vel.x < 0:
                self.vel.x = 0
                self.rect.left = collision.rect.right
                self.player_flip = False

        self.rect.y += self.vel.y + 0.5 * self.acc.y

        collision_list = pg.sprite.spritecollide(self, self.game.walls, False)

        for collision in collision_list:
            if self.vel.y > 0:
                self.vel.y = 0
                self.rect.bottom = collision.rect.top

            elif self.vel.y < 0:
                self.vel.y = 0
                self.rect.top = collision.rect.bottom

        # changes the animation state
        if self.vel.x > 0:
            self.animationState, self.currentFrame = self.changeState(self.animationState, self.currentFrame, "Run")


        if self.vel.x == 0:
            self.animationState, self.currentFrame = self.changeState(self.animationState, self.currentFrame, "Idle")

        if self.vel.x < 0:
            self.animationState, self.currentFrame = self.changeState(self.animationState, self.currentFrame, "Run")


        # appends animation frames
        self.currentFrame += 1
        if self.currentFrame >= len(self.animationDataBase[self.animationState]):
            self.currentFrame = 0

        self.imgID = self.animationDataBase[self.animationState][self.currentFrame]
        self.image = pg.transform.flip(self.animationsFrames[self.imgID], self.player_flip, False)

        #health settings
        if self.health <= 0:
            self.kill()

class WaddleDooL(pg.sprite.Sprite):
    def __init__(self, game, x, y):
        self.groups = game.all_sprites, game.WaddleDoo
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.image = pg.Surface((TILESIZE * 3, TILESIZE * 3))
        self.rect = self.image.get_rect()
        self.pos = vec(x,y)
        self.rect.center = self.pos
        # animation stuff
        self.animationsFrames = {}
        self.animationDataBase = {}
        self.animationDataBase["Idle"] = self.load_animations("images/Waddle Doo/Idle", [18, 14, 18])
        self.animationDataBase["Run"] = self.load_animations("images/Waddle Doo/Run", [5, 5, 5, 5, 5])
        self.animationDataBase["Attack"] = self.load_animations("images/Waddle Doo/Attack", [8, 6])
        self.currentFrame = 0
        self.animationState = "Idle"
        self.player_flip = True
        self.attacking = True
        #way its facing
        self.vel = vec(0, 0)
        self.acc = vec(0, 0)
        #health
        self.health = WaddleHealth
        self.enemyHealth = player_HEALTH


    #more animation stuff
    def load_animations(self, path, frame_dur):
        animationName = path.split("/")[-1]
        animationFrameData = []
        n = 0
        for frames in frame_dur:
            animationID = animationName + str(n)
            imgLocation = path + "/" + animationID + ".png"
            animationImage = pg.image.load(imgLocation).convert_alpha()
            #resize images
            if animationName == "Attack":
                animationImage = pg.transform.scale(animationImage, (73, 55))
            elif animationName == "Run":
                animationImage = pg.transform.scale(animationImage, (56, 60))
            elif animationName == "Idle":
                animationImage = pg.transform.scale(animationImage, (TILESIZE *4, 60))

            self.animationsFrames[animationID] = animationImage.copy()
            for i in range(frames):
                animationFrameData.append(animationID)
            n += 1
        return animationFrameData

    def changeState(self, currentState, Frame, newState):
        if currentState != newState:
            currentState = newState
            Frame = 0
        return newState, Frame

    def update(self):
        # left and right movement
        self.acc = vec(0, player_GRAV)
        if self.player_flip == False:
            self.acc.x = mob_ACC
        else:
            self.acc.x = -mob_ACC

        # apply friction
        self.acc.x += self.vel.x * player_FRICTION
        # equations of motion
        self.vel += self.acc

        # attack stuff
        if self.rect.colliderect(self.game.player.rect):
            self.game.player.health -= WaddleDamage
            self.game.player.hit()

        self.rect.x += self.vel.x + 0.5 * self.acc.x

        collision_list = pg.sprite.spritecollide(self, self.game.walls, False)

        for collision in collision_list:
            if self.vel.x > 0:
                self.vel.x = 0
                self.rect.right = collision.rect.left
                self.player_flip = True

            elif self.vel.x < 0:
                self.vel.x = 0
                self.rect.left = collision.rect.right
                self.player_flip = False

        self.rect.y += self.vel.y + 0.5 * self.acc.y

        collision_list = pg.sprite.spritecollide(self, self.game.walls, False)

        for collision in collision_list:
            if self.vel.y > 0:
                self.vel.y = 0
                self.rect.bottom = collision.rect.top

            elif self.vel.y < 0:
                self.vel.y = 0
                self.rect.top = collision.rect.bottom

        # changes the animation state
        if self.vel.x > 0:
            self.animationState, self.currentFrame = self.changeState(self.animationState, self.currentFrame, "Run")


        if self.vel.x == 0:
            self.animationState, self.currentFrame = self.changeState(self.animationState, self.currentFrame, "Idle")

        if self.vel.x < 0:
            self.animationState, self.currentFrame = self.changeState(self.animationState, self.currentFrame, "Run")


        # appends animation frames
        self.currentFrame += 1
        if self.currentFrame >= len(self.animationDataBase[self.animationState]):
            self.currentFrame = 0

        self.imgID = self.animationDataBase[self.animationState][self.currentFrame]
        self.image = pg.transform.flip(self.animationsFrames[self.imgID], self.player_flip, False)

        #health settings
        if self.health <= 0:
            self.kill()

class WaddleDeeR(pg.sprite.Sprite):
    def __init__(self, game, x, y):
        self.groups = game.all_sprites, game.WaddleDee
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.image = pg.Surface((TILESIZE * 3, TILESIZE * 3))
        self.rect = self.image.get_rect()
        self.pos = vec(x,y)
        self.rect.center = self.pos
        # animation stuff
        self.animationsFrames = {}
        self.animationDataBase = {}
        self.animationDataBase["Idle"] = self.load_animations("images/Waddle Dee/Idle", [18, 14, 18])
        self.animationDataBase["Run"] = self.load_animations("images/Waddle Dee/Run", [5, 5, 5, 5, 5])
        #self.animationDataBase["Attack"] = self.load_animations("images/Waddle Dee/Attack", [8, 6])
        self.currentFrame = 0
        self.animationState = "Idle"
        self.player_flip = False
        self.attacking = True
        #way its facing
        self.vel = vec(0, 0)
        self.acc = vec(0, 0)
        #health
        self.health = WaddleHealth
        self.enemyHealth = player_HEALTH


    #more animation stuff
    def load_animations(self, path, frame_dur):
        animationName = path.split("/")[-1]
        animationFrameData = []
        n = 0
        for frames in frame_dur:
            animationID = animationName + str(n)
            imgLocation = path + "/" + animationID + ".png"
            animationImage = pg.image.load(imgLocation).convert_alpha()
            #resize images
            if animationName == "Attack":
                animationImage = pg.transform.scale(animationImage, (73, 55))
            elif animationName == "Run":
                animationImage = pg.transform.scale(animationImage, (56, 60))
            elif animationName == "Idle":
                animationImage = pg.transform.scale(animationImage, (TILESIZE *4, 60))

            self.animationsFrames[animationID] = animationImage.copy()
            for i in range(frames):
                animationFrameData.append(animationID)
            n += 1
        return animationFrameData

    def changeState(self, currentState, Frame, newState):
        if currentState != newState:
            currentState = newState
            Frame = 0
        return newState, Frame

    def update(self):
        # left and right movement
        self.acc = vec(0, player_GRAV)
        if self.player_flip == False:
            self.acc.x = mob_ACC
        else:
            self.acc.x = -mob_ACC

        # apply friction
        self.acc.x += self.vel.x * player_FRICTION
        # equations of motion
        self.vel += self.acc

        # attack stuff
        if self.rect.colliderect(self.game.player.rect):
            self.game.player.health -= WaddleDamage
            self.game.player.hit()

        self.rect.x += self.vel.x + 0.5 * self.acc.x

        collision_list = pg.sprite.spritecollide(self, self.game.walls, False)

        for collision in collision_list:
            if self.vel.x > 0:
                self.vel.x = 0
                self.rect.right = collision.rect.left
                self.player_flip = True

            elif self.vel.x < 0:
                self.vel.x = 0
                self.rect.left = collision.rect.right
                self.player_flip = False

        self.rect.y += self.vel.y + 0.5 * self.acc.y

        collision_list = pg.sprite.spritecollide(self, self.game.walls, False)

        for collision in collision_list:
            if self.vel.y > 0:
                self.vel.y = 0
                self.rect.bottom = collision.rect.top

            elif self.vel.y < 0:
                self.vel.y = 0
                self.rect.top = collision.rect.bottom

        # changes the animation state
        if self.vel.x > 0:
            self.animationState, self.currentFrame = self.changeState(self.animationState, self.currentFrame, "Run")


        if self.vel.x == 0:
            self.animationState, self.currentFrame = self.changeState(self.animationState, self.currentFrame, "Idle")

        if self.vel.x < 0:
            self.animationState, self.currentFrame = self.changeState(self.animationState, self.currentFrame, "Run")


        # appends animation frames
        self.currentFrame += 1
        if self.currentFrame >= len(self.animationDataBase[self.animationState]):
            self.currentFrame = 0

        self.imgID = self.animationDataBase[self.animationState][self.currentFrame]
        self.image = pg.transform.flip(self.animationsFrames[self.imgID], self.player_flip, False)

        #health settings
        if self.health <= 0:
            self.kill()

class WaddleDeeL(pg.sprite.Sprite):
    def __init__(self, game, x, y):
        self.groups = game.all_sprites, game.WaddleDee
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.image = pg.Surface((TILESIZE * 3, TILESIZE * 3))
        self.rect = self.image.get_rect()
        self.pos = vec(x,y)
        self.rect.center = self.pos
        # animation stuff
        self.animationsFrames = {}
        self.animationDataBase = {}
        self.animationDataBase["Idle"] = self.load_animations("images/Waddle Dee/Idle", [18, 14, 18])
        self.animationDataBase["Run"] = self.load_animations("images/Waddle Dee/Run", [5, 5, 5, 5, 5])
        #self.animationDataBase["Attack"] = self.load_animations("images/Waddle Dee/Attack", [8, 6])
        self.currentFrame = 0
        self.animationState = "Idle"
        self.player_flip = True
        self.attacking = True
        #way its facing
        self.vel = vec(0, 0)
        self.acc = vec(0, 0)
        #health
        self.health = WaddleHealth
        self.enemyHealth = player_HEALTH


    #more animation stuff
    def load_animations(self, path, frame_dur):
        animationName = path.split("/")[-1]
        animationFrameData = []
        n = 0
        for frames in frame_dur:
            animationID = animationName + str(n)
            imgLocation = path + "/" + animationID + ".png"
            animationImage = pg.image.load(imgLocation).convert_alpha()
            #resize images
            if animationName == "Attack":
                animationImage = pg.transform.scale(animationImage, (73, 55))
            elif animationName == "Run":
                animationImage = pg.transform.scale(animationImage, (56, 60))
            elif animationName == "Idle":
                animationImage = pg.transform.scale(animationImage, (TILESIZE *4, 60))

            self.animationsFrames[animationID] = animationImage.copy()
            for i in range(frames):
                animationFrameData.append(animationID)
            n += 1
        return animationFrameData

    def changeState(self, currentState, Frame, newState):
        if currentState != newState:
            currentState = newState
            Frame = 0
        return newState, Frame

    def update(self):
        # left and right movement
        self.acc = vec(0, player_GRAV)
        if self.player_flip == False:
            self.acc.x = mob_ACC
        else:
            self.acc.x = -mob_ACC

        # apply friction
        self.acc.x += self.vel.x * player_FRICTION
        # equations of motion
        self.vel += self.acc

        # attack stuff
        if self.rect.colliderect(self.game.player.rect):
            self.game.player.health -= WaddleDamage
            self.game.player.hit()
        self.rect.x += self.vel.x + 0.5 * self.acc.x

        collision_list = pg.sprite.spritecollide(self, self.game.walls, False)

        for collision in collision_list:
            if self.vel.x > 0:
                self.vel.x = 0
                self.rect.right = collision.rect.left
                self.player_flip = True

            elif self.vel.x < 0:
                self.vel.x = 0
                self.rect.left = collision.rect.right
                self.player_flip = False

        self.rect.y += self.vel.y + 0.5 * self.acc.y

        collision_list = pg.sprite.spritecollide(self, self.game.walls, False)

        for collision in collision_list:
            if self.vel.y > 0:
                self.vel.y = 0
                self.rect.bottom = collision.rect.top

            elif self.vel.y < 0:
                self.vel.y = 0
                self.rect.top = collision.rect.bottom

        # changes the animation state
        if self.vel.x > 0:
            self.animationState, self.currentFrame = self.changeState(self.animationState, self.currentFrame, "Run")


        if self.vel.x == 0:
            self.animationState, self.currentFrame = self.changeState(self.animationState, self.currentFrame, "Idle")

        if self.vel.x < 0:
            self.animationState, self.currentFrame = self.changeState(self.animationState, self.currentFrame, "Run")


        # appends animation frames
        self.currentFrame += 1
        if self.currentFrame >= len(self.animationDataBase[self.animationState]):
            self.currentFrame = 0

        self.imgID = self.animationDataBase[self.animationState][self.currentFrame]
        self.image = pg.transform.flip(self.animationsFrames[self.imgID], self.player_flip, False)

        #health settings
        if self.health <= 0:
            self.kill()

class Scarfy(pg.sprite.Sprite):
    def __init__(self, game, x, y):
        self.groups = game.all_sprites, game.Scarfy
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.image = pg.Surface((TILESIZE * 3, TILESIZE * 3))
        self.rect = self.image.get_rect()
        self.pos = vec(x,y)
        self.rect.center = self.pos
        # animation stuff
        self.animationsFrames = {}
        self.animationDataBase = {}
        self.animationDataBase["Idle"] = self.load_animations("images/Scarfy/Idle", [10, 10, 10, 10])
        #self.animationDataBase["Run"] = self.load_animations("images/Scarfy/Run", [5, 5, 5, 5, 5])
        self.animationDataBase["Attack"] = self.load_animations("images/Scarfy/Attack", [12, 12, 12])
        self.currentFrame = 0
        self.animationState = "Idle"
        self.player_flip = False
        self.attacking = True
        #way its facing
        self.vel = vec(0, 0)
        self.acc = vec(0, 0)
        #health
        self.health = ScarfyHealth
        self.enemyHealth = player_HEALTH


    #more animation stuff
    def load_animations(self, path, frame_dur):
        animationName = path.split("/")[-1]
        animationFrameData = []
        n = 0
        for frames in frame_dur:
            animationID = animationName + str(n)
            imgLocation = path + "/" + animationID + ".png"
            animationImage = pg.image.load(imgLocation).convert_alpha()
            #resize images
            if animationName == "Attack":
                animationImage = pg.transform.scale(animationImage, (73, 55))
            elif animationName == "Run":
                animationImage = pg.transform.scale(animationImage, (56, 60))
            elif animationName == "Idle":
                animationImage = pg.transform.scale(animationImage, (TILESIZE *4, 60))

            self.animationsFrames[animationID] = animationImage.copy()
            for i in range(frames):
                animationFrameData.append(animationID)
            n += 1
        return animationFrameData

    def changeState(self, currentState, Frame, newState):
        if currentState != newState:
            currentState = newState
            Frame = 0
        return newState, Frame

    def update(self):
        # left and right movement
        if self.player_flip == False:
            self.acc.x = ScarfySpeed
        else:
            self.acc.x = -ScarfySpeed

        # apply friction
        self.acc.x += self.vel.x * ScarfyFriction
        # equations of motion
        self.vel += self.acc

        # Dual personality
        self.CrazyBox = pg.Rect(self.rect.x - 300, self.rect.y, 600, 300)

        # attack stuff
        if self.rect.colliderect(self.game.player.rect):
            self.game.player.health -= ScarfyDamage
            self.game.player.hit()

        self.rect.x += self.vel.x + 0.5 * self.acc.x

        collision_list = pg.sprite.spritecollide(self, self.game.walls, False)

        for collision in collision_list:
            if self.vel.x > 0:
                self.vel.x = 0
                self.rect.right = collision.rect.left
                self.player_flip = True

            elif self.vel.x < 0:
                self.vel.x = 0
                self.rect.left = collision.rect.right
                self.player_flip = False

        self.rect.y += self.vel.y + 0.5 * self.acc.y

        collision_list = pg.sprite.spritecollide(self, self.game.walls, False)

        for collision in collision_list:
            if self.vel.y > 0:
                self.vel.y = 0
                self.rect.bottom = collision.rect.top

            elif self.vel.y < 0:
                self.vel.y = 0
                self.rect.top = collision.rect.bottom

        # changes the animation state
        #if self.vel.x > 0:
            #self.animationState, self.currentFrame = self.changeState(self.animationState, self.currentFrame, "Run")


        if self.vel.x > 0 or self.vel.x < 0:
            self.animationState, self.currentFrame = self.changeState(self.animationState, self.currentFrame, "Idle")

        if self.CrazyBox.colliderect(self.game.player.rect):
            self.animationDataBase["Idle"] = self.load_animations("images/Scarfy/Idle", [3, 3, 3, 3])
            #self.animationState, self.currentFrame = self.changeState(self.animationState, self.currentFrame, "Attack")
            self.vel.x *= -5
        else:
            self.animationDataBase["Idle"] = self.load_animations("images/Scarfy/Idle", [10, 10, 10, 10])

            #if self.vel.x < 0:
        #    self.animationState, self.currentFrame = self.changeState(self.animationState, self.currentFrame, "Run")


        # appends animation frames
        self.currentFrame += 1
        if self.currentFrame >= len(self.animationDataBase[self.animationState]):
            self.currentFrame = 0

        self.imgID = self.animationDataBase[self.animationState][self.currentFrame]
        self.image = pg.transform.flip(self.animationsFrames[self.imgID], self.player_flip, False)

        #health settings
        if self.health <= 0:
            self.kill()

class Bullet(pg.sprite.Sprite):
    def __init__(self, x, y):
        pg.sprite.Sprite.__init__(self)
        self.image = pg.image.load("images/Burnin/Attack4.png").convert()
        self.image.set_colorkey(BLACK)
        self.rect = self.image.get_rect()
        self.rect.bottom = y
        self.rect.centerx = x
        self.speedy = -10

    def update(self):
        self.rect.x += self.speedy
        # kill if it moves off the top of the screen
        if self.rect.left < 0:
            self.kill()

class BurninL(pg.sprite.Sprite):
    def __init__(self, game, x, y):
        self.groups = game.all_sprites, game.Burnin, game.bullets
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.image = pg.Surface((TILESIZE * 3, TILESIZE * 3))
        self.rect = self.image.get_rect()
        self.pos = vec(x,y)
        self.rect.center = self.pos
        # animation stuff
        self.animationsFrames = {}
        self.animationDataBase = {}
        self.animationDataBase["Idle"] = self.load_animations("images/Burnin/Idle", [18, 14])
        self.animationDataBase["Run"] = self.load_animations("images/Burnin/Run", [5, 5, 5, 5])
        self.animationDataBase["Attack"] = self.load_animations("images/Burnin/Attack", [8, 6, 8, 8])
        self.currentFrame = 0
        self.animationState = "Idle"
        self.player_flip = True
        self.attacking = True
        #way its facing
        self.vel = vec(0, 0)
        self.acc = vec(0, 0)
        #health
        self.health = BurninHealth
        self.enemyHealth = player_HEALTH
        #attack
        self.shoot_delay = 200
        self.last_shot = pg.time.get_ticks()


    #more animation stuff
    def load_animations(self, path, frame_dur):
        animationName = path.split("/")[-1]
        animationFrameData = []
        n = 0
        for frames in frame_dur:
            animationID = animationName + str(n)
            imgLocation = path + "/" + animationID + ".png"
            animationImage = pg.image.load(imgLocation).convert_alpha()
            #resize images
            if animationName == "Attack":
                animationImage = pg.transform.scale(animationImage, (73, 55))
            elif animationName == "Run":
                animationImage = pg.transform.scale(animationImage, (56, 60))
            elif animationName == "Idle":
                animationImage = pg.transform.scale(animationImage, (TILESIZE *4, 55))

            self.animationsFrames[animationID] = animationImage.copy()
            for i in range(frames):
                animationFrameData.append(animationID)
            n += 1
        return animationFrameData

    def changeState(self, currentState, Frame, newState):
        if currentState != newState:
            currentState = newState
            Frame = 0
        return newState, Frame

    def shoot(self):
        now = pg.time.get_ticks()
        if now - self.last_shot > self.shoot_delay:
            self.last_shot = now
            bullet = Bullet(self.rect.centerx, self.rect.bottom - 5)
            self.game.all_sprites.add(bullet)
            self.game.bullets.add(bullet)
        hits = pg.sprite.spritecollide(self.game.player, self.game.bullets, True, False)
        if hits:
            self.game.player.health -= FireDamage


    def update(self):
        # left and right movement
        self.acc = vec(0, player_GRAV)
        if self.player_flip == False:
            self.acc.x = 0
        else:
            self.acc.x = -0

        # apply friction
        self.acc.x += self.vel.x * player_FRICTION
        # equations of motion
        self.vel += self.acc

        # attack stuff
        self.attackBox = pg.Rect(self.rect.x - 500, self.rect.y, 500, 30)
        if self.rect.colliderect(self.game.player.rect):
            self.game.player.health -= BurninDamage
            self.game.player.hit()

        self.rect.x += self.vel.x + 0.5 * self.acc.x

        collision_list = pg.sprite.spritecollide(self, self.game.walls, False)

        for collision in collision_list:
            if self.vel.x > 0:
                self.vel.x = 0
                self.rect.right = collision.rect.left
                self.player_flip = True

            elif self.vel.x < 0:
                self.vel.x = 0
                self.rect.left = collision.rect.right
                self.player_flip = False

        self.rect.y += self.vel.y + 0.5 * self.acc.y

        collision_list = pg.sprite.spritecollide(self, self.game.walls, False)

        for collision in collision_list:
            if self.vel.y > 0:
                self.vel.y = 0
                self.rect.bottom = collision.rect.top

            elif self.vel.y < 0:
                self.vel.y = 0
                self.rect.top = collision.rect.bottom

        # changes the animation state
        if self.vel.x > 0:
            self.animationState, self.currentFrame = self.changeState(self.animationState, self.currentFrame, "Run")


        if self.vel.x == 0:
            self.animationState, self.currentFrame = self.changeState(self.animationState, self.currentFrame, "Idle")


        if self.attackBox.colliderect(self.game.player.rect):
            self.vel.x = 0
            self.animationState, self.currentFrame = self.changeState(self.animationState, self.currentFrame, "Attack")
            self.shoot()

        if self.vel.x < 0:
            self.animationState, self.currentFrame = self.changeState(self.animationState, self.currentFrame, "Run")


        # appends animation frames
        self.currentFrame += 1
        if self.currentFrame >= len(self.animationDataBase[self.animationState]):
            self.currentFrame = 0

        self.imgID = self.animationDataBase[self.animationState][self.currentFrame]
        self.image = pg.transform.flip(self.animationsFrames[self.imgID], self.player_flip, False)

        #health settings
        if self.health <= 0:
            self.kill()

class BulletR(pg.sprite.Sprite):
    def __init__(self, x, y):
        pg.sprite.Sprite.__init__(self)
        self.image = pg.image.load("images/Burnin/Attack4.png").convert()
        self.image.set_colorkey(BLACK)
        self.rect = self.image.get_rect()
        self.rect.bottom = y
        self.rect.centerx = x
        self.speedy = 10

    def update(self):
        self.rect.x += self.speedy
        # kill if it moves off the top of the screen
        if self.rect.left < 0:
            self.kill()

class BurninR(pg.sprite.Sprite):
    def __init__(self, game, x, y):
        self.groups = game.all_sprites, game.Burnin, game.bullets
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.image = pg.Surface((TILESIZE * 3, TILESIZE * 3))
        self.rect = self.image.get_rect()
        self.pos = vec(x,y)
        self.rect.center = self.pos
        # animation stuff
        self.animationsFrames = {}
        self.animationDataBase = {}
        self.animationDataBase["Idle"] = self.load_animations("images/Burnin/Idle", [18, 14])
        self.animationDataBase["Run"] = self.load_animations("images/Burnin/Run", [5, 5, 5, 5])
        self.animationDataBase["Attack"] = self.load_animations("images/Burnin/Attack", [8, 6, 8, 8])
        self.currentFrame = 0
        self.animationState = "Idle"
        self.player_flip = False
        self.attacking = True
        #way its facing
        self.vel = vec(0, 0)
        self.acc = vec(0, 0)
        #health
        self.health = BurninHealth
        self.enemyHealth = player_HEALTH
        #attack
        self.shoot_delay = 200
        self.last_shot = pg.time.get_ticks()


    #more animation stuff
    def load_animations(self, path, frame_dur):
        animationName = path.split("/")[-1]
        animationFrameData = []
        n = 0
        for frames in frame_dur:
            animationID = animationName + str(n)
            imgLocation = path + "/" + animationID + ".png"
            animationImage = pg.image.load(imgLocation).convert_alpha()
            #resize images
            if animationName == "Attack":
                animationImage = pg.transform.scale(animationImage, (73, 55))
            elif animationName == "Run":
                animationImage = pg.transform.scale(animationImage, (56, 60))
            elif animationName == "Idle":
                animationImage = pg.transform.scale(animationImage, (TILESIZE *4, 55))

            self.animationsFrames[animationID] = animationImage.copy()
            for i in range(frames):
                animationFrameData.append(animationID)
            n += 1
        return animationFrameData

    def changeState(self, currentState, Frame, newState):
        if currentState != newState:
            currentState = newState
            Frame = 0
        return newState, Frame

    def shoot(self):
        now = pg.time.get_ticks()
        if now - self.last_shot > self.shoot_delay:
            self.last_shot = now
            bullet = BulletR(self.rect.centerx, self.rect.bottom - 5)
            self.game.all_sprites.add(bullet)
            self.game.bullets.add(bullet)
        hits = pg.sprite.spritecollide(self.game.player, self.game.bullets, True, False)
        if hits:
            self.game.player.health -= FireDamage


    def update(self):
        # left and right movement
        self.acc = vec(0, player_GRAV)
        if self.player_flip == False:
            self.acc.x = 0
        else:
            self.acc.x = -0

        # apply friction
        self.acc.x += self.vel.x * player_FRICTION
        # equations of motion
        self.vel += self.acc

        # attack stuff
        self.attackBox = pg.Rect(self.rect.x, self.rect.y, 500, 30)
        if self.rect.colliderect(self.game.player.rect):
            self.game.player.health -= BurninDamage
            self.game.player.hit()

        self.rect.x += self.vel.x + 0.5 * self.acc.x

        collision_list = pg.sprite.spritecollide(self, self.game.walls, False)

        for collision in collision_list:
            if self.vel.x > 0:
                self.vel.x = 0
                self.rect.right = collision.rect.left
                self.player_flip = True

            elif self.vel.x < 0:
                self.vel.x = 0
                self.rect.left = collision.rect.right
                self.player_flip = False

        self.rect.y += self.vel.y + 0.5 * self.acc.y

        collision_list = pg.sprite.spritecollide(self, self.game.walls, False)

        for collision in collision_list:
            if self.vel.y > 0:
                self.vel.y = 0
                self.rect.bottom = collision.rect.top

            elif self.vel.y < 0:
                self.vel.y = 0
                self.rect.top = collision.rect.bottom

        # changes the animation state
        if self.vel.x > 0:
            self.animationState, self.currentFrame = self.changeState(self.animationState, self.currentFrame, "Run")


        if self.vel.x == 0:
            self.animationState, self.currentFrame = self.changeState(self.animationState, self.currentFrame, "Idle")


        if self.attackBox.colliderect(self.game.player.rect):
            self.vel.x = 0
            self.animationState, self.currentFrame = self.changeState(self.animationState, self.currentFrame, "Attack")
            self.shoot()

        if self.vel.x < 0:
            self.animationState, self.currentFrame = self.changeState(self.animationState, self.currentFrame, "Run")


        # appends animation frames
        self.currentFrame += 1
        if self.currentFrame >= len(self.animationDataBase[self.animationState]):
            self.currentFrame = 0

        self.imgID = self.animationDataBase[self.animationState][self.currentFrame]
        self.image = pg.transform.flip(self.animationsFrames[self.imgID], self.player_flip, False)

        #health settings
        if self.health <= 0:
            self.kill()

class ChillyR(pg.sprite.Sprite):
    def __init__(self, game, x, y):
        self.groups = game.all_sprites, game.Chilly
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.image = pg.Surface((TILESIZE * 3, TILESIZE * 3))
        self.rect = self.image.get_rect()
        self.pos = vec(x,y)
        self.rect.center = self.pos
        # animation stuff
        self.animationsFrames = {}
        self.animationDataBase = {}
        self.animationDataBase["Idle"] = self.load_animations("images/Chilly/Idle", [18, 14, 18])
        self.animationDataBase["Run"] = self.load_animations("images/Chilly/Run", [10, 10])
        #self.animationDataBase["Attack"] = self.load_animations("images/Waddle Dee/Attack", [8, 6])
        self.currentFrame = 0
        self.animationState = "Idle"
        self.player_flip = False
        self.attacking = True
        #way its facing
        self.vel = vec(0, 0)
        self.acc = vec(0, 0)
        #health
        self.health = ChillyHealth
        self.enemyHealth = player_HEALTH


    #more animation stuff
    def load_animations(self, path, frame_dur):
        animationName = path.split("/")[-1]
        animationFrameData = []
        n = 0
        for frames in frame_dur:
            animationID = animationName + str(n)
            imgLocation = path + "/" + animationID + ".png"
            animationImage = pg.image.load(imgLocation).convert_alpha()
            #resize images
            if animationName == "Attack":
                animationImage = pg.transform.scale(animationImage, (73, 55))
            elif animationName == "Run":
                animationImage = pg.transform.scale(animationImage, (56, 60))
            elif animationName == "Idle":
                animationImage = pg.transform.scale(animationImage, (TILESIZE *4, 60))

            self.animationsFrames[animationID] = animationImage.copy()
            for i in range(frames):
                animationFrameData.append(animationID)
            n += 1
        return animationFrameData

    def changeState(self, currentState, Frame, newState):
        if currentState != newState:
            currentState = newState
            Frame = 0
        return newState, Frame

    def update(self):
        # left and right movement
        self.acc = vec(0, player_GRAV)
        if self.player_flip == False:
            self.acc.x = mob_ACC
        else:
            self.acc.x = -mob_ACC

        # apply friction
        self.acc.x += self.vel.x * player_FRICTION
        # equations of motion
        self.vel += self.acc

        # attack stuff
        if self.rect.colliderect(self.game.player.rect):
            self.game.player.health -= ChillyDamage
            self.game.player.hit()

        self.rect.x += self.vel.x + 0.5 * self.acc.x

        collision_list = pg.sprite.spritecollide(self, self.game.walls, False)

        for collision in collision_list:
            if self.vel.x > 0:
                self.vel.x = 0
                self.rect.right = collision.rect.left
                self.player_flip = True

            elif self.vel.x < 0:
                self.vel.x = 0
                self.rect.left = collision.rect.right
                self.player_flip = False

        self.rect.y += self.vel.y + 0.5 * self.acc.y

        collision_list = pg.sprite.spritecollide(self, self.game.walls, False)

        for collision in collision_list:
            if self.vel.y > 0:
                self.vel.y = 0
                self.rect.bottom = collision.rect.top

            elif self.vel.y < 0:
                self.vel.y = 0
                self.rect.top = collision.rect.bottom

        # changes the animation state
        if self.vel.x > 0:
            self.animationState, self.currentFrame = self.changeState(self.animationState, self.currentFrame, "Run")


        if self.vel.x == 0:
            self.animationState, self.currentFrame = self.changeState(self.animationState, self.currentFrame, "Idle")

        if self.vel.x < 0:
            self.animationState, self.currentFrame = self.changeState(self.animationState, self.currentFrame, "Run")


        # appends animation frames
        self.currentFrame += 1
        if self.currentFrame >= len(self.animationDataBase[self.animationState]):
            self.currentFrame = 0

        self.imgID = self.animationDataBase[self.animationState][self.currentFrame]
        self.image = pg.transform.flip(self.animationsFrames[self.imgID], self.player_flip, False)

        #health settings
        if self.health <= 0:
            self.kill()

class ChillyL(pg.sprite.Sprite):
    def __init__(self, game, x, y):
        self.groups = game.all_sprites, game.Chilly
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.image = pg.Surface((TILESIZE * 3, TILESIZE * 3))
        self.rect = self.image.get_rect()
        self.pos = vec(x,y)
        self.rect.center = self.pos
        # animation stuff
        self.animationsFrames = {}
        self.animationDataBase = {}
        self.animationDataBase["Idle"] = self.load_animations("images/Chilly/Idle", [18, 14, 18])
        self.animationDataBase["Run"] = self.load_animations("images/Chilly/Run", [10, 10])
        #self.animationDataBase["Attack"] = self.load_animations("images/Waddle Dee/Attack", [8, 6])
        self.currentFrame = 0
        self.animationState = "Idle"
        self.player_flip = True
        self.attacking = True
        #way its facing
        self.vel = vec(0, 0)
        self.acc = vec(0, 0)
        #health
        self.health = ChillyHealth
        self.enemyHealth = player_HEALTH


    #more animation stuff
    def load_animations(self, path, frame_dur):
        animationName = path.split("/")[-1]
        animationFrameData = []
        n = 0
        for frames in frame_dur:
            animationID = animationName + str(n)
            imgLocation = path + "/" + animationID + ".png"
            animationImage = pg.image.load(imgLocation).convert_alpha()
            #resize images
            if animationName == "Attack":
                animationImage = pg.transform.scale(animationImage, (73, 55))
            elif animationName == "Run":
                animationImage = pg.transform.scale(animationImage, (56, 60))
            elif animationName == "Idle":
                animationImage = pg.transform.scale(animationImage, (TILESIZE *4, 60))

            self.animationsFrames[animationID] = animationImage.copy()
            for i in range(frames):
                animationFrameData.append(animationID)
            n += 1
        return animationFrameData

    def changeState(self, currentState, Frame, newState):
        if currentState != newState:
            currentState = newState
            Frame = 0
        return newState, Frame

    def update(self):
        # left and right movement
        self.acc = vec(0, player_GRAV)
        if self.player_flip == False:
            self.acc.x = mob_ACC
        else:
            self.acc.x = -mob_ACC

        # apply friction
        self.acc.x += self.vel.x * player_FRICTION
        # equations of motion
        self.vel += self.acc

        # attack stuff
        if self.rect.colliderect(self.game.player.rect):
            self.game.player.health -= ChillyDamage
            self.game.player.hit()

        self.rect.x += self.vel.x + 0.5 * self.acc.x

        collision_list = pg.sprite.spritecollide(self, self.game.walls, False)

        for collision in collision_list:
            if self.vel.x > 0:
                self.vel.x = 0
                self.rect.right = collision.rect.left
                self.player_flip = True

            elif self.vel.x < 0:
                self.vel.x = 0
                self.rect.left = collision.rect.right
                self.player_flip = False

        self.rect.y += self.vel.y + 0.5 * self.acc.y

        collision_list = pg.sprite.spritecollide(self, self.game.walls, False)

        for collision in collision_list:
            if self.vel.y > 0:
                self.vel.y = 0
                self.rect.bottom = collision.rect.top

            elif self.vel.y < 0:
                self.vel.y = 0
                self.rect.top = collision.rect.bottom

        # changes the animation state
        if self.vel.x > 0:
            self.animationState, self.currentFrame = self.changeState(self.animationState, self.currentFrame, "Run")


        if self.vel.x == 0:
            self.animationState, self.currentFrame = self.changeState(self.animationState, self.currentFrame, "Idle")

        if self.vel.x < 0:
            self.animationState, self.currentFrame = self.changeState(self.animationState, self.currentFrame, "Run")


        # appends animation frames
        self.currentFrame += 1
        if self.currentFrame >= len(self.animationDataBase[self.animationState]):
            self.currentFrame = 0

        self.imgID = self.animationDataBase[self.animationState][self.currentFrame]
        self.image = pg.transform.flip(self.animationsFrames[self.imgID], self.player_flip, False)

        #health settings
        if self.health <= 0:
            self.kill()



# Objects
class Obstacle(pg.sprite.Sprite):
    def __init__(self, game, x, y, w, h):
        self.groups = game.walls
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.rect = pg.Rect(x, y, w, h)
        self.x = x
        self.y = y
        self.rect.x = x
        self.rect.y = y

class Spikes(pg.sprite.Sprite):
    def __init__(self, game, x, y, w, h):
        self.group = game.spikes
        pg.sprite.Sprite.__init__(self, self.group)
        self.game = game
        self.rect = pg.Rect(x, y, w, h)
        self.x = x
        self.y = y
        self.rect.x = x
        self.rect.y = y
        self.damage = player_HEALTH

class Flag(pg.sprite.Sprite):
    def __init__(self, game, x, y, w, h):
        self.group = game.flag
        pg.sprite.Sprite.__init__(self, self.group)
        self.game = game
        self.rect = pg.Rect(x, y, w, h)
        self.x = x
        self.y = y
        self.rect.x = x
        self.rect.y = y

class HP(pg.sprite.Sprite):
    def __init__(self, game, x, y):
        self.group = game.all_sprites, game.HP
        pg.sprite.Sprite.__init__(self, self.group)
        self.game = game
        self.image = pg.image.load("images/Heart.png").convert()
        self.image = pg.transform.scale(self.image, (80, 80))
        self.image.set_colorkey(BLACK)
        self.rect = self.image.get_rect()
        self.rect.center = (x,y)
        self.health = 20

class Coin(pg.sprite.Sprite):
    def __init__(self, game, x, y):
        self.group = game.all_sprites, game.coin
        pg.sprite.Sprite.__init__(self, self.group)
        self.game = game
        self.image = pg.image.load("images/coin.png").convert()
        self.image = pg.transform.scale(self.image, (30, 30))
        self.image.set_colorkey(BLACK)
        self.rect = self.image.get_rect()
        self.rect.center = (x,y)
        self.score = 50

class DestroyWall(pg.sprite.Sprite):
     def __init__(self, game, x, y, img):
        self.groups = game.walls, game.DestroyWall, game.all_sprites
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.x = x
        self.y = y
        self.image = img
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

class Wall(pg.sprite.Sprite):
    def __init__(self, game, x, y):
        self.groups = game.all_sprites, game.walls
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.image = pg.Surface((TILESIZE, TILESIZE))
        self.image.fill(GREEN)
        self.rect = self.image.get_rect()
        self.x = x
        self.y = y
        self.rect.x = x * TILESIZE
        self.rect.y = y * TILESIZE


