import pygame as pg

#Colours
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
DARKGREY = (40, 40, 40)
LIGHTGREY = (100, 100, 100)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
YELLOW = (255, 255, 0)
periwinkle = (204, 204, 255)
sansEye = (132, 255, 242)

# game settings
WIDTH = 1280   # 16 * 64 or 32 * 32 or 64 * 16
HEIGHT = 720  # 16 * 48 or 32 * 24 or 64 * 12
FPS = 60
TITLE = "Kirby Strikes Back"
BGCOLOR = DARKGREY
HS_LIST =  ("0.txt", "1.txt", "2.txt", "3.txt")
Level_List = ("Tutorial1.tmx", "Level1.tmx", "Level2.tmx", "Level3a.tmx")
damage_alpha =  [i for i in range(100, 255, 25)]

TILESIZE = 16
GRIDWIDTH = WIDTH / TILESIZE
GRIDHEIGHT = HEIGHT / TILESIZE

# player properties
player_ACC = 5
player_FRICTION = -1
player_GRAV = 1
player_JUMP = 20
player_HEALTH = 200
player_Damage = 10
score = 0

# Sounds
splashMusic = "Staff-Roll-Kirby-Super-Star.ogg"
mainMenuMusic = "Moonstruck-Blossom-Kirby-Triple-Deluxe.ogg"
levelMusic = "Kirby-Wii-Music-Selection-Soundtrack-CD-The-Final-Battle-_Magolor_s-Theme-Medley_.ogg"
introvideo = "Kirby Opening Scene No Ref.mov"
effects = {"attack": "attack.wav", "death": "death.wav", "jump":"jump.wav", "victory": "victory.wav", "damage":"damage.wav", "coin" : "coin.wav"}
#Enemy Properties
mob_ACC = 1
mob_FRICTION = -1
mob_KNOCKBACK = 20
#The Waddle
WaddleDamage = 5
WaddleHealth = 30
# The Scarfy
ScarfyDamage = 10
ScarfyHealth = 50
ScarfySpeed = 1
ScarfyFriction = -1
# The Burn
BurninDamage = 1
BurninHealth = 100
FireDamage = 40
# The Chill
ChillyDamage = 10
ChillyHealth = 60
