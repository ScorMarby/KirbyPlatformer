<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.4" name="2015-02-26 [DB32](Generic Platformer)(Mountains)" tilewidth="32" tileheight="32" tilecount="32" columns="8">
 <image source="../images/SpriteSheet/2015-02-26 [DB32](Generic Platformer)(Mountains).png" width="256" height="144"/>
</tileset>
