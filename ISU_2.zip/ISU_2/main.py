import pygame as pg

import sys
from time import sleep
from os import path
from settings import *
from sprites import *
from tilemap import *

# creates rectangle that shogws the players health.
def drawPlayerHealth(surf, x, y, pct):
    if pct < 0:
        pct = 0
    Bar_LENGTH = 100
    Bar_Height = 20
    fill = pct * Bar_LENGTH
    outline_rect = pg.Rect(x, y, Bar_LENGTH, Bar_Height)
    fill_rect = pg.Rect(x,y, fill, Bar_Height)
    if pct > 0.6:
        col= GREEN
    elif pct > 0.3:
        col = YELLOW
    else:
        col = RED
    pg.draw.rect(surf,col,fill_rect)
    pg.draw.rect(surf, WHITE, outline_rect, 2)

# class for the game loop
class Game:
    def __init__(self):
        pg.init()
        self.screen = pg.display.set_mode((WIDTH, HEIGHT))
        pg.display.set_caption(TITLE)
        self.clock = pg.time.Clock()
        pg.key.set_repeat(500, 100)
        self.running = True
        self.levelnum = None
        self.font = pg.font.match_font("Tisa")

    def load_data(self):
        self.game_folder = path.dirname(__file__)
        try:
            # try to read the file
            with open(path.join(self.game_folder, HS_LIST[self.levelnum]), 'r+') as f:
                self.highscore = int(f.read())
        except:
            # create the file
            with open(path.join(self.game_folder, HS_LIST[self.levelnum]), 'w'):
                self.highscore = 0
        self.img_folder = path.join(self.game_folder, "images")
        self.map_folder = path.join(self.game_folder, "maps")
        self.music_folder = path.join(self.game_folder, "music")
        self.map = TiledMap(path.join(self.map_folder, Level_List[self.levelnum]))
        self.map_img = self.map.make_map()
        self.map_rect = self.map_img.get_rect()
        # Music loading
        pg.mixer.music.load(path.join(self.music_folder, levelMusic))

        #sound loading
        self.effects_sounds = {}
        for type in effects:
            self.effects_sounds[type] = pg.mixer.Sound(path.join(self.music_folder, effects[type]))

    def new(self):
        self.load_data()
        # initialize all variables and do all the setup for a new game
        self.all_sprites = pg.sprite.Group()
        self.walls = pg.sprite.Group()
        self.WaddleDoo = pg.sprite.Group()
        self.WaddleDee = pg.sprite.Group()
        self.Scarfy = pg.sprite.Group()
        self.Burnin = pg.sprite.Group()
        self.Chilly = pg.sprite.Group()
        self.bullets = pg.sprite.Group()
        self.Player = pg.sprite.Group()
        self.spikes = pg.sprite.Group()
        self.DestroyWall = pg.sprite.Group()
        self.flag = pg.sprite.Group()
        self.HP = pg.sprite.Group()
        self.coin = pg.sprite.Group()
        # score
        self.score = score
        # dim screen while paused
        self.dim_screen = pg.Surface(self.screen.get_size()).convert_alpha()
        self.dim_screen.fill((0,0,0, 180))
        # takes num and letter from tilemap
        #for row, tiles in enumerate(self.map.data):
        #    for col, tile in enumerate(tiles):
        #        if tile == '1':
        #            Wall(self, col, row)
        #        if tile == 'W':
        #            WaddleDoo(self, col, row,)
        #        if tile == 'P':
        #            self.player = Player(self, col, row)
        for tile_object in self.map.tmxdata.objects:
            if tile_object.name == "Player":
                self.player = Player(self, tile_object.x, tile_object.y)
            if tile_object.name == "WaddleDooR":
                WaddleDooR(self, tile_object.x, tile_object.y)
            if tile_object.name == "WaddleDooL":
                WaddleDooL(self, tile_object.x, tile_object.y)
            if tile_object.name == "WaddleDeeL":
                WaddleDeeL(self, tile_object.x, tile_object.y)
            if tile_object.name == "WaddleDeeR":
                WaddleDeeR(self, tile_object.x, tile_object.y)
            if tile_object.name == "Scarfy":
                Scarfy(self, tile_object.x, tile_object.y)
            if tile_object.name == "BurninL":
                BurninL(self, tile_object.x, tile_object.y)
            if tile_object.name == "BurninR":
                BurninR(self, tile_object.x, tile_object.y)
            if tile_object.name == "ChillyR":
                ChillyR(self, tile_object.x, tile_object.y)
            if tile_object.name == "ChillyL":
                ChillyL(self, tile_object.x, tile_object.y)
            if tile_object.name == "Ground":
                Obstacle(self, tile_object.x, tile_object.y, tile_object.width, tile_object.height)
            if tile_object.name == "Break":
                DestroyWall(self, tile_object.x, tile_object.y, pg.transform.scale(pg.image.load(path.join(self.img_folder, "break.png")), (32,32)))
            if tile_object.name == "Spikes":
                Spikes(self, tile_object.x, tile_object.y, tile_object.width, tile_object.height)
            if tile_object.name == "Flag":
                Flag(self, tile_object.x, tile_object.y, tile_object.width, tile_object.height)
            if tile_object.name == "Health":
                HP(self, tile_object.x, tile_object.y)
            if tile_object.name == "Coin":
                Coin(self, tile_object.x, tile_object.y)
        self.camera = Camera(self.map.width, self.map.height)
        # pause
        self.paused = False

    def run(self):
        # game loop - set self.playing = False to end the game
        self.playing = True
        pg.mixer.music.play(loops=-1)
        pg.mixer.music.set_volume(0.3)
        while self.playing:
            self.dt = self.clock.tick(FPS) / 1000
            self.events()
            if not self.paused:
                self.update()
            self.draw()

    def quit(self):
        pg.quit()
        sys.exit()

    def update(self):
        self.score = self.player.score
        # update portion of the game loop
        self.all_sprites.update()
        self.camera.update(self.player)
        if self.player.health <= 0:
            self.playing = False
        #print(score)

        #def draw_grid(self):
        #   for x in range(0, WIDTH, TILESIZE):
        #      pg.draw.line(self.screen, LIGHTGREY, (x, 0), (x, HEIGHT))
        # for y in range(0, HEIGHT, TILESIZE):
        #    pg.draw.line(self.screen, LIGHTGREY, (0, y), (WIDTH, y))

    def draw(self):
        #self.screen.fill(BGCOLOR)
        #self.draw_grid()
        self.screen.blit(self.map_img, self.camera.apply_rect(self.map_rect))
        for sprite in self.all_sprites:
            self.screen.blit(sprite.image, self.camera.apply(sprite))
        self.drawText("Score: " + str(self.score), 30, BLACK, 650, 50)
        self.drawText("Level: " + str(self.levelnum), 30, BLACK, 650, 22)
        #HUD functions
        drawPlayerHealth(self.screen, 10, 10, self.player.health / player_HEALTH)
        if self.paused:
            self.screen.blit(self.dim_screen, (0, 0))
            self.drawText("Paused", 64, WHITE, WIDTH / 2, HEIGHT / 2)
        pg.display.flip()

    def events(self):
        # catch all events here
        for event in pg.event.get():
            if event.type == pg.QUIT:
                self.quit()
            if event.type == pg.KEYDOWN:
                if event.key == pg.K_SPACE:
                    self.player.jump()
                if event.key == pg.K_ESCAPE:
                    self.paused = not self.paused

    # shows the main menu where user can select the level, open control, difficulty menu or quit.
    def MainMenu(self):
        waiting = True
        keys = pg.key.get_pressed()
        # game splash screen
        self.level0 = Button(WIDTH / 4.5, HEIGHT / 2, 50, 50, "0", self.font, 30, BLACK, WHITE)
        self.level1 = Button(WIDTH / 2.5, HEIGHT / 2, 50, 50, "1", self.font, 30, BLACK, WHITE)
        self.level2 = Button(WIDTH / 1.65, HEIGHT / 2, 50, 50, "2", self.font, 30, BLACK, WHITE)
        self.level3 = Button(WIDTH / 1.30, HEIGHT / 2, 50, 50, "3", self.font, 30, BLACK, WHITE)
        self.Difficulty = Button(WIDTH / 2, HEIGHT / 1.25, 200, 50, "Difficulty", self.font, 30, BLACK, WHITE)
        self.Controls = Button(WIDTH / 2, HEIGHT / 1.5, 200, 50, "Controls", self.font, 30, BLACK, WHITE)
        self.game_folder = path.dirname(__file__)
        self.music_folder = path.join(self.game_folder, "music")
        pg.mixer.music.load(path.join(self.music_folder, mainMenuMusic))
        pg.mixer.music.play(loops=-1)
        pg.mixer.music.set_volume(1)
        while waiting:

            mousepos = pg.mouse.get_pos()
            self.clock.tick(FPS)
            self.splashScreen_img = pg.transform.scale(pg.image.load("images/Pictures/SplashScreen.png"), (1280, 1020))
            self.screen.blit(self.splashScreen_img, (0, 0))
            #self.screen.fill(sansEye)
            #self.inhale = pg.transform.scale(pg.image.load("images/inhale.png"), (700, 500))
            #self.screen.blit(self.inhale, (375, 150))
            #self.screen.blit(pg.image.load("images/hamburger.png"), (275, 100))
            self.level0.Draw(self.screen, BLACK)
            self.level1.Draw(self.screen, BLACK)
            self.level2.Draw(self.screen, BLACK)
            self.level3.Draw(self.screen, BLACK)
            self.Difficulty.Draw(self.screen, BLACK)
            self.Controls.Draw(self.screen, BLACK)
            self.drawText(TITLE, 64, BLACK, WIDTH / 2, HEIGHT / 6)
            self.drawText("Level Select:", 40, BLACK, WIDTH / 3.5, HEIGHT / 2.3)
            pg.display.flip()
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    waiting = False
                    self.running = False
                if event.type == pg.MOUSEMOTION:
                    if self.level0.Is_Over(mousepos):
                        self.level0.colour = LIGHTGREY
                    else:
                        self.level0.colour = BLACK
                    if self.level1.Is_Over(mousepos):
                        self.level1.colour = LIGHTGREY
                    else:
                        self.level1.colour = BLACK
                    if self.level2.Is_Over(mousepos):
                        self.level2.colour = LIGHTGREY
                    else:
                        self.level2.colour = BLACK
                    if self.level3.Is_Over(mousepos):
                        self.level3.colour = LIGHTGREY
                    else:
                        self.level3.colour = BLACK
                    if self.Difficulty.Is_Over(mousepos):
                        self.Difficulty.colour = LIGHTGREY
                    else:
                        self.Difficulty.colour = BLACK
                    if self.Controls.Is_Over(mousepos):
                        self.Controls.colour = LIGHTGREY
                    else:
                        self.Controls.colour = BLACK
                    if self.Difficulty.Is_Over(mousepos):
                        self.Difficulty.colour = LIGHTGREY
                    else:
                        self.Difficulty.colour = BLACK
                if event.type == pg.MOUSEBUTTONDOWN:
                    if self.level0.Is_Over(mousepos):
                        self.levelnum = 0
                        waiting = False
                if event.type == pg.MOUSEBUTTONDOWN:
                    if self.level1.Is_Over(mousepos):
                        self.levelnum = 1
                        waiting = False
                if event.type == pg.MOUSEBUTTONDOWN:
                    if self.level2.Is_Over(mousepos):
                        self.levelnum = 2
                        waiting = False
                if event.type == pg.MOUSEBUTTONDOWN:
                    if self.level3.Is_Over(mousepos):
                        self.levelnum = 3
                        waiting = False
                if event.type == pg.MOUSEBUTTONDOWN:
                    if self.Controls.Is_Over(mousepos):
                        self.Control()
                        waiting = False
                if event.type == pg.MOUSEBUTTONDOWN:
                    if self.Difficulty.Is_Over(mousepos):
                        self.Difficulties()
                        waiting = False

    # opens menu where player can see controls.
    def Control(self):
        waiting = True
        keys = pg.key.get_pressed()
        self.Back = Button(25, 25, 50, 50, "<---", self.font, 30, BLACK, WHITE)
        while waiting:
            mousepos = pg.mouse.get_pos()
            self.screen.fill(WHITE)
            self.Back.Draw(self.screen, BLACK)
            self.screen.blit(pg.image.load("images/wasd.png"), (100, 100))
            self.drawText("Use WASD to Move. Space to Jump", 48, BLACK, 340, 525)
            self.e_key = pg.transform.scale(pg.image.load("images/e_key.png"), (200, 200))
            self.screen.blit(self.e_key, (700, 200))
            self.drawText("E to attack", 48, BLACK ,800, 525)
            #self.screen.blit(pg.image.load("images/spacebar-clipart-5.png"), (100, 100))
            pg.display.flip()
            self.clock.tick(FPS)
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    waiting = False
                    self.running = False
                if event.type == pg.MOUSEMOTION:
                    if self.Back.Is_Over(mousepos):
                        self.Back.colour = LIGHTGREY
                    else:
                        self.Back.colour = BLACK
                if event.type == pg.MOUSEBUTTONDOWN:
                    if self.Back.Is_Over(mousepos):
                        self.MainMenu()
                        waiting = False
                if event.type == pg.KEYDOWN:
                    if event.key == pg.K_ESCAPE:
                        self.MainMenu()
                        waiting = False

    # opens up difficulty menu where user can select Hard, Hard or Hard. Does nothing.
    def Difficulties(self):
        waiting = True
        keys = pg.key.get_pressed()
        self.Hard1 = Button(WIDTH / 5, HEIGHT / 2.25, 250, 300, "HARD", self.font, 30, BLACK, WHITE)
        self.Hard2 = Button(WIDTH / 2, HEIGHT / 2.25, 250, 300, "HARD", self.font, 30, BLACK, WHITE)
        self.Hard3 = Button(WIDTH / 1.25, HEIGHT / 2.25, 250, 300, "HARD", self.font, 30, BLACK, WHITE)
        self.Back1 = Button(25, 25, 50, 50, "<---", self.font, 30, BLACK, WHITE)
        while waiting:
            mousepos = pg.mouse.get_pos()
            self.screen.fill(BLACK)
            self.Hard1.Draw(self.screen, WHITE)
            self.Hard2.Draw(self.screen, WHITE)
            self.Hard3.Draw(self.screen, WHITE)
            self.Back1.Draw(self.screen, WHITE)
            pg.display.flip()
            self.clock.tick(FPS)
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    waiting = False
                    self.running = False
                if event.type == pg.MOUSEMOTION:
                    if self.Back1.Is_Over(mousepos):
                        self.Back1.colour = LIGHTGREY
                    else:
                        self.Back1.colour = BLACK
                if event.type == pg.MOUSEBUTTONDOWN:
                    if self.Back1.Is_Over(mousepos):
                        self.MainMenu()
                        waiting = False
                if event.type == pg.MOUSEBUTTONDOWN:
                    if self.Hard1.Is_Over(mousepos):
                        self.MainMenu()
                        waiting = False
                if event.type == pg.MOUSEBUTTONDOWN:
                    if self.Hard2.Is_Over(mousepos):
                        self.MainMenu()
                        waiting = False
                if event.type == pg.MOUSEBUTTONDOWN:
                    if self.Hard3.Is_Over(mousepos):
                        self.MainMenu()
                        waiting = False
                if event.type == pg.MOUSEMOTION:
                    if self.Hard1.Is_Over(mousepos):
                        self.Hard1.colour = LIGHTGREY
                    else:
                        self.Hard1.colour = BLACK
                if event.type == pg.MOUSEMOTION:
                    if self.Hard2.Is_Over(mousepos):
                        self.Hard2.colour = LIGHTGREY
                    else:
                        self.Hard2.colour = BLACK
                if event.type == pg.MOUSEMOTION:
                    if self.Hard3.Is_Over(mousepos):
                        self.Hard3.colour = LIGHTGREY
                    else:
                        self.Hard3.colour = BLACK
                if event.type == pg.KEYDOWN:
                    if event.key == pg.K_ESCAPE:
                        self.MainMenu()
                        waiting = False
                if event.type == pg.KEYUP:
                    waiting = False

    # plays when player completes the level
    def CompleteScreen(self):
        self.score = self.player.score
        waiting = True
        self.Home = Button(WIDTH/2, HEIGHT/1.25, 200, 50, "Main Menu", self.font, 32, BLACK, WHITE)
        self.Continue = Button(WIDTH/2, HEIGHT/ 1.5, 200, 50, "Next Level", self.font, 32, BLACK, WHITE)
        if self.score > self.highscore:
            with open(path.join(self.game_folder, HS_LIST[self.levelnum]), "w") as f:
                f.write(str(self.score))
        self.effects_sounds["victory"].play()
        pg.mixer.music.stop()
        while waiting:
            mousepos = pg.mouse.get_pos()
            self.screen.fill(BLACK)
            self.Home.Draw(self.screen, WHITE)
            self.Continue.Draw(self.screen, WHITE)
            self.clock.tick(FPS)
            if self.score > self.highscore:
                self.drawText("New Highscore!! : " + str(self.score), 100, WHITE, WIDTH / 2, HEIGHT / 5)
            else:
                self.drawText("Highscore = " + str(self.highscore), 40, WHITE, WIDTH / 2, HEIGHT / 5)
                self.drawText("Current Score = " + str(self.score), 40, WHITE, WIDTH / 2, HEIGHT / 3)
                self.drawText("Better Luck Next Time", 40, WHITE, WIDTH / 2, HEIGHT / 2.5)
            pg.display.flip()
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    waiting = False
                    self.running = False
                if event.type == pg.MOUSEMOTION:
                    if self.Home.Is_Over(mousepos):
                        self.Home.colour = LIGHTGREY
                    else:
                        self.Home.colour = BLACK
                if event.type == pg.MOUSEBUTTONDOWN:
                    if self.Home.Is_Over(mousepos):
                        self.MainMenu()
                        waiting = False
                if event.type == pg.MOUSEMOTION:
                    if self.Continue.Is_Over(mousepos):
                        self.Continue.colour = LIGHTGREY
                    else:
                        self.Continue.colour = BLACK
                if event.type == pg.MOUSEBUTTONDOWN:
                    if self.Continue.Is_Over(mousepos):
                        self.levelnum += 1
                        waiting = False

    # plays the initial loading screen with name of game and group members
    def SplashScreen(self):
        waiting = True
        keys = pg.key.get_pressed()
        self.screen.fill(BLACK)
        self.game_folder = path.dirname(__file__)
        # play splashscreen music
        self.music_folder = path.join(self.game_folder, "music")
        pg.mixer.music.load(path.join(self.music_folder, splashMusic))
        pg.mixer.music.play(loops=-1)
        pg.mixer.music.set_volume(1)
        # intro loading
        while waiting:
            self.splashScreen_img = pg.transform.scale(pg.image.load("images/Pictures/Splash2.png"), (1360, 1020))
            self.screen.blit(self.splashScreen_img, (0, -127))
            self.drawText("Game by Marco Stupp-Acosta", 32, BLACK, WIDTH / 7, HEIGHT / 1.02)
            self.drawText("Press any button to start", 64, BLACK, WIDTH / 2, HEIGHT / 1.2)
            self.drawText(TITLE, 100, BLACK, WIDTH / 2, HEIGHT / 6)
            pg.display.flip()
            self.clock.tick(FPS)
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    waiting = False
                    self.running = False
                if event.type == pg.KEYUP:
                    self.MainMenu()
                    pg.mixer.music.fadeout(10)
                    waiting = False

    # plays when last level is completed
    def FinalScreen(self):
        self.score = self.player.score
        waiting = True
        self.Home2 = Button(WIDTH / 2, HEIGHT / 1.25, 200, 50, "Main Menu", self.font, 32, BLACK, WHITE)
        if self.score > self.highscore:
            with open(path.join(self.game_folder, HS_LIST[self.levelnum]), "w") as f:
                f.write(str(self.score))
        self.effects_sounds["victory"].play()
        pg.mixer.music.stop()
        while waiting:
            mousepos = pg.mouse.get_pos()
            self.screen.fill(BLACK)
            self.Home2.Draw(self.screen, WHITE)
            self.clock.tick(FPS)
            if self.score > self.highscore:
                self.drawText("New Highscore!! : " + str(self.score), 100, WHITE, WIDTH / 2, HEIGHT / 5)
                self.drawText("You Win!! ", 100, WHITE, WIDTH / 2, HEIGHT / 3)
            else:
                self.drawText("Highscore = " + str(self.highscore), 40, WHITE, WIDTH / 2, HEIGHT / 5)
                self.drawText("Current Score = " + str(self.score), 40, WHITE, WIDTH / 2, HEIGHT / 3)
                self.drawText("You Win. Try Again?" , 40, WHITE, WIDTH / 2, HEIGHT / 2.5)
            pg.display.flip()
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    waiting = False
                    self.running = False
                if event.type == pg.MOUSEMOTION:
                    if self.Home2.Is_Over(mousepos):
                        self.Home2.colour = LIGHTGREY
                    else:
                        self.Home2.colour = BLACK
                if event.type == pg.MOUSEBUTTONDOWN:
                    if self.Home2.Is_Over(mousepos):
                        self.MainMenu()
                        waiting = False

    # plays when player dies. Gives option to try again or quit.
    def Death(self):
        waiting = True
        keys = pg.key.get_pressed()
        self.Home1 = Button(WIDTH / 2, HEIGHT / 1.25, 200, 50, "Main Menu", self.font, 32, BLACK, WHITE)
        self.Continue1 = Button(WIDTH / 2, HEIGHT / 1.5, 200, 50, "Try Again", self.font, 32, BLACK, WHITE)
        self.effects_sounds["death"].play()
        pg.mixer.music.stop()
        while waiting:
            mousepos = pg.mouse.get_pos()
            self.screen.fill(BLACK)
            self.drawText("GAME OVER ", 100, WHITE, WIDTH / 2, HEIGHT / 5)
            self.Home1.Draw(self.screen, WHITE)
            self.Continue1.Draw(self.screen, WHITE)
            # self.screen.blit(pg.image.load("images/spacebar-clipart-5.png"), (100, 100))
            pg.display.flip()
            self.clock.tick(FPS)
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    waiting = False
                    self.running = False
                if event.type == pg.MOUSEMOTION:
                    if self.Home1.Is_Over(mousepos):
                        self.Home1.colour = LIGHTGREY
                    else:
                        self.Home1.colour = BLACK
                if event.type == pg.MOUSEBUTTONDOWN:
                    if self.Home1.Is_Over(mousepos):
                        self.MainMenu()
                        waiting = False
                if event.type == pg.MOUSEMOTION:
                    if self.Continue1.Is_Over(mousepos):
                        self.Continue1.colour = LIGHTGREY
                    else:
                        self.Continue1.colour = BLACK
                if event.type == pg.MOUSEBUTTONDOWN:
                    if self.Continue1.Is_Over(mousepos):
                        self.levelnum
                        waiting = False
                if event.type == pg.KEYDOWN:
                    if event.key == pg.K_ESCAPE:
                        self.MainMenu()
                        waiting = False

    def drawText(self, text, size, colour, x, y):
        font = pg.font.Font(self.font, size)
        text_surface = font.render(text, True, colour)
        text_rect = text_surface.get_rect()
        text_rect.center = (x, y)
        self.screen.blit(text_surface, text_rect)


class Button(pg.sprite.Sprite):
    def __init__(self, x, y, w, h, text, font, size, colour, font_col):
        pg.sprite.Sprite.__init__(self)
        self.text = text
        self.font = font
        self.size = size
        self.colour = colour
        self.font_col = font_col
        self.x = x
        self.y = y
        self.width = w
        self.height = h
        self.rect = pg.Rect(x, y, self.width, self.height)
        self.rect.center = (x, y)

    def Draw(self, surface, outline):
        if outline:
            pg.draw.rect(surface, outline,
                         (self.x - self.width / 2 - 2, self.y - self.height / 2 - 2, self.width + 4, self.height + 4),
                         0)
        pg.draw.rect(surface, self.colour, self.rect, 0)
        if self.text != "":
            font = pg.font.Font(self.font, self.size)
            text_Surface = font.render(self.text, True, self.font_col)
            text_rect = text_Surface.get_rect()
            text_rect.center = (self.x, self.y)
            surface.blit(text_Surface, text_rect)

    def Is_Over(self, pos):
        if self.x - self.width / 2 < pos[0] < self.x + self.width / 2:
            if self.y - self.height / 2 < pos[1] < self.y + self.height / 2:
                return True
        else:
            return False



# create the game object and holds the loop that runs the game.
g = Game()
g.SplashScreen()
while g.running:
    g.new()
    g.run()
    if g.player.health <= 0:
        g.Death()
    elif g.levelnum == 3:
        g.FinalScreen()
    else:
        g.CompleteScreen()

