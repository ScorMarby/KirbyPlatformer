<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.4" name="Tileset (2)" tilewidth="32" tileheight="32" tilecount="336" columns="24">
 <image source="../images/SpriteSheet/Tileset (2).png" width="791" height="461"/>
</tileset>
