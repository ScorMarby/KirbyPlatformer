<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.4" name="cloud" tilewidth="32" tileheight="32" tilecount="60" columns="10">
 <image source="../images/SpriteSheet/cloud.png" width="336" height="192"/>
</tileset>
